package com.example.rahipart2.Prevalent;

import com.example.rahipart2.Model.Users;

public class Prevalent
{
      private   static Users currentonlineUsers;

      public static final String Usernamekey = "Username";
      public static final String Userpasswordkey = "Userpassword";

}
